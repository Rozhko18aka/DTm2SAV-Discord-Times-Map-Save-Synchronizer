import json
import tempfile
import unittest
import struct
from pathlib import Path

import army_runtime as ar
import game_resources as gr

ROOT = Path(__file__).resolve().parents[1]
BASE = json.loads((ROOT / "army_catalog.json").read_text(encoding="utf-8"))


def write_sections(path: Path, entries, *, dict_mode: bool) -> None:
    lines = []
    iterable = entries.items() if dict_mode else enumerate(entries, 1)
    for _key, entry in iterable:
        section = entry.get("_section", str(_key))
        lines.append(f"[{section}]")
        for key, value in entry.items():
            if key == "_section":
                continue
            lines.append(f"{key}={value}")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def make_game_dir(root: Path, *, unit_cost_override: str | None = None, unit_multiplier_override: str | None = None, artifact_hits_override: str | None = None, recruit_div: str = "2") -> None:
    units = json.loads(json.dumps(BASE["units"], ensure_ascii=False))
    if unit_cost_override is not None:
        units["1"]["Cost"] = unit_cost_override
    if unit_multiplier_override is not None:
        units["1"]["CostMultipler"] = unit_multiplier_override
    artifacts = json.loads(json.dumps(BASE["artifacts"], ensure_ascii=False))
    if artifact_hits_override is not None:
        artifacts["1"]["d-Hits"] = artifact_hits_override
    write_sections(root / "Rus_Units.ini", units, dict_mode=True)
    write_sections(root / "Rus_Artefacts.ini", artifacts, dict_mode=True)
    write_sections(root / "Rus_Spells.ini", BASE["spells"], dict_mode=False)
    (root / "_Global.ini").write_text(f"CostRecruitDiv={recruit_div}\n", encoding="utf-8")
    obj = root / "Graphics" / "Objects"
    obj.mkdir(parents=True)
    ugs = bytearray()
    for index in range(200):
        kind = index // 256
        variant = index % 256
        ugs += struct.pack("<5I", kind, variant, 1, 1, 1)
        ugs += struct.pack("<I", 0xFF204060)
        ugs += struct.pack("<HH", 1, 1)
        ugs += b"\x00\x00"
    (obj / "Objects.ugs").write_bytes(ugs)


class GameResourcesTests(unittest.TestCase):
    def tearDown(self):
        ar.clear_active_catalog()

    def test_cp1251_legacy_ini_is_supported(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "Rus_Units.ini"
            path.write_bytes("[1 Рыцарь]\r\nGlobalIndex=1\r\nName=Рыцарь\r\nCost=280\r\n".encode("cp1251"))
            sections = gr.parse_legacy_ini(path)
            self.assertEqual(sections[0][0], "1 Рыцарь")
            self.assertEqual(sections[0][1]["Name"], "Рыцарь")

    def test_missing_files_are_fatal(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(gr.GameDataError) as cm:
                gr.load_game_resources(Path(td), objects_parser=lambda _p: {})
            text = str(cm.exception)
            self.assertIn("Не удаётся загрузить данные игры", text)
            self.assertIn("корневую папку Discord Times", text)
            self.assertIn("Rus_Units.ini", text)
            self.assertIn("Graphics", text)

    def test_real_objects_ugs_parser_runs_during_startup(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root)
            resources = gr.load_game_resources(root)
            self.assertEqual(resources.objects_ugs, root / "Graphics" / "Objects" / "Objects.ugs")

    def test_baseline_game_files_load_without_profile_warning(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root)
            resources = gr.load_game_resources(root, objects_parser=lambda _p: {1: object()})
            self.assertFalse(resources.has_untested_data)
            self.assertEqual(len(resources.catalog["units"]), len(BASE["units"]))
            self.assertEqual(len(resources.catalog["artifacts"]), len(BASE["artifacts"]))
            self.assertEqual(len(resources.catalog["spells"]), len(BASE["spells"]))
            self.assertEqual(float(resources.catalog["_global"]["CostRecruitDiv"]), 2.0)
            self.assertEqual(resources.objects_ugs, root / "Graphics" / "Objects" / "Objects.ugs")

    def test_modified_unit_warns_but_installs_and_strict_synthesis_is_allowed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root, unit_cost_override="333")
            resources = gr.load_game_resources(root, objects_parser=lambda _p: {1: object()})
            self.assertTrue(resources.has_untested_data)
            self.assertIn(1, resources.changed_units)
            self.assertIn("тестирование не проводилось", resources.warning_text())
            gr.install_game_resources(resources)
            self.assertEqual(ar.load_catalog()["units"]["1"]["Cost"], "333")
            # Profile 1:99 does not exist.  Because the live game definition is
            # modified, strict native-profile gating must not block saving.
            record = ar.make_unit_record(1, 99, True, 0, 0, [], ar.load_catalog(), strict_derived=True)
            self.assertEqual(len(record), ar.UNIT_STRIDE)

    def test_modified_global_divisor_is_loaded_and_warned(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root, recruit_div="3")
            resources = gr.load_game_resources(root, objects_parser=lambda _p: {1: object()})
            self.assertTrue(resources.global_changed)
            self.assertEqual(float(resources.catalog["_global"]["CostRecruitDiv"]), 3.0)

    def test_duplicate_spell_sections_keep_positional_ids(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root)
            spell_path = root / "Rus_Spells.ini"
            spell_path.write_text(
                "[Заклинание]\nName=Первое\nd-Hits=1\n\n"
                "[Заклинание]\nName=Второе\nd-Hits=2\n",
                encoding="utf-8",
            )
            resources = gr.load_game_resources(root, objects_parser=lambda _p: {1: object()})
            self.assertEqual([x["Name"] for x in resources.catalog["spells"]], ["Первое", "Второе"])
            self.assertEqual(resources.changed_spells[0], 1)


    def test_modified_values_are_used_in_runtime_calculation(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root, unit_cost_override="333", unit_multiplier_override="120", recruit_div="3")
            resources = gr.load_game_resources(root, objects_parser=lambda _p: {1: object()})
            gr.install_game_resources(resources)
            catalog = ar.load_catalog()
            unit = catalog["units"]["1"]
            self.assertEqual(ar._payment_guess(1, 0, catalog, strict=True), ar.calculate_upkeep(unit, 3))
            base = ar._base_stats(unit, 0)
            components = ar.calculate_tactical_components(base, unit, unit.get("Bonus") or "", runtime_compat=True)
            record = ar.make_unit_record(1, 0, True, 0, 0, [], catalog, strict_derived=True)
            self.assertEqual(int.from_bytes(record[0x1AA:0x1AE], "little"), components["tactical_cost"])

    def test_modified_artifact_uses_live_modifier_and_drops_native_modified_profile(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root, artifact_hits_override="77")
            resources = gr.load_game_resources(root, objects_parser=lambda _p: {1: object()})
            gr.install_game_resources(resources)
            catalog = ar.load_catalog()
            self.assertIn(1, resources.changed_artifacts)
            self.assertEqual(ar._native_modified_profile(1, 0, [1], 0, catalog), {})
            record = ar.make_unit_record(1, 0, True, 0, 0, [1], catalog, strict_derived=True)
            modified_hits = int.from_bytes(record[0x0DD + 1:0x0DD + 5], "little", signed=True)
            self.assertEqual(modified_hits, int(catalog["units"]["1"]["Hits"]) + 77)

    def test_objects_parser_failure_is_fatal(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_game_dir(root)
            with self.assertRaises(gr.GameDataError) as cm:
                gr.load_game_resources(root, objects_parser=lambda _p: (_ for _ in ()).throw(ValueError("bad ugs")))
            self.assertIn("Не удаётся загрузить данные игры", str(cm.exception))
            self.assertIn("bad ugs", str(cm.exception))


if __name__ == "__main__":
    unittest.main()
