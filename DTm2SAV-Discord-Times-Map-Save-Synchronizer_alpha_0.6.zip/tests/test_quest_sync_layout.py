import struct
import unittest

import dtm_sav_quest_sync as qs


def empty_case(width, height):
    original = bytearray(0x40)
    original[:12] = b"MapLDV V.4\r\n"
    struct.pack_into("<II", original, 0x0C, width, height)
    payload = bytes(38 * width * height)
    sections = {
        "buildings": {"count": 0},
        "lanterns": {"count": 0},
        "armies": {"count": 0},
    }
    relationship = {
        "compiled_grid": {"offset": 0, "cell_layers_size": len(payload)},
        "dynamic_tail": {},
    }
    return payload, bytes(original), sections, relationship


class TestEmptyCellTableFallback(unittest.TestCase):
    def test_native_100_layout(self):
        self.assertEqual(qs.infer_cell_table(*empty_case(100, 100)), (90740, 108))

    def test_native_200_layout(self):
        self.assertEqual(qs.infer_cell_table(*empty_case(200, 200)), (377540, 208))

    def test_unknown_empty_geometry_is_not_guessed(self):
        with self.assertRaises(qs.QuestSyncError):
            qs.infer_cell_table(*empty_case(150, 150))


if __name__ == "__main__":
    unittest.main()
