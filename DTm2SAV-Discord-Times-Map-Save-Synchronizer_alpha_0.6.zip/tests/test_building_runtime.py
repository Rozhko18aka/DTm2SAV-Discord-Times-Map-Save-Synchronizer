import hashlib
import struct
import unittest

import army_runtime
import building_runtime as br


def raw_building(*, x=10, y=10, typ=3, sx=1, sy=1, defence=0, garrison=(), artifacts=(), market_count=0, min_price=0, max_price=0, gold=0, mana=0):
    b = bytearray(br.BUILDING_SIZE)
    struct.pack_into('<HH', b, 0, x, y)
    b[br.TYPE_OFF] = typ
    b[br.SIZE_X_OFF] = sx
    b[br.SIZE_Y_OFF] = sy
    b[br.GARRISON_DEFENCE_OFF] = defence
    struct.pack_into('<H', b, br.GOLD_INCOME_OFF, gold)
    b[br.MANA_INCOME_OFF] = mana
    b[br.MARKET_COUNT_OFF] = market_count
    struct.pack_into('<HH', b, br.MIN_ARTIFACT_PRICE_OFF, min_price, max_price)
    for i, (uid, level, count) in enumerate(garrison):
        b[br.GARRISON_OFF + 3*i: br.GARRISON_OFF + 3*i + 3] = bytes((uid, level, count))
    for i, item_id in enumerate(artifacts):
        struct.pack_into('<H', b, br.ARTIFACTS_OFF + 2*i, item_id)
    return bytes(b)


def army_raw(army_id=1, start_building=0):
    b = bytearray(89)
    b[4] = army_id
    b[0x19] = start_building
    return bytes(b)


class TestBuildingLayout(unittest.TestCase):
    def test_overlapping_footprints_later_building_wins_navigation(self):
        def rec(x, y, sx, sy, kind=3):
            raw = bytearray(br.BUILDING_SIZE)
            struct.pack_into("<HH", raw, 0, x, y)
            raw[br.TYPE_OFF] = kind
            raw[br.SIZE_X_OFF] = sx
            raw[br.SIZE_Y_OFF] = sy
            return br.parse_building_record(bytes(raw))

        first = rec(5, 5, 3, 3)   # footprint x=3..5, y=3..5
        second = rec(4, 4, 2, 2)  # footprint x=3..4, y=3..4
        owners = br.expected_navigation_owners([first, second], 208)
        self.assertEqual(owners[(3, 3)], (4 + 208 * 4, 2))
        self.assertEqual(owners[(5, 5)], (5 + 208 * 5, 1))

    def test_native_offsets(self):
        self.assertEqual(br.BUILDING_SIZE, 358)
        self.assertEqual(br.RECRUITS_OFF, 264)
        self.assertEqual(br.OWNER_ARMY_OFF, 292)
        self.assertEqual(br.BARRACKS_OFF, 294)
        self.assertEqual(br.MARKET_COUNT_OFF, 295)
        self.assertEqual(br.SPELLS_OFF, 308)
        self.assertEqual(br.GARRISON_OFF, 314)
        self.assertEqual(br.GARRISON_DEFENCE_OFF, 332)
        self.assertEqual(br.GROUP_OFF, 337)
        self.assertEqual(br.MANA_INCOME_OFF, 350)

    def test_runtime_coords_and_footprint(self):
        r = br.parse_building_record(raw_building(x=15, y=9, sx=8, sy=7))
        self.assertEqual(r.runtime_coords, (8, 3))
        self.assertEqual(len(r.footprint), 56)
        self.assertIn((8, 3), r.footprint)
        self.assertIn((15, 9), r.footprint)


class TestBuildingAlignment(unittest.TestCase):
    def test_delete_middle(self):
        old = [raw_building(x=i, typ=3) for i in (1,2,3,4)]
        new = [old[0], old[1], old[3]]
        mapping, deleted = br.align_buildings(old, new)
        self.assertEqual(mapping, [0,1,3])
        self.assertEqual(deleted, [2])
        self.assertTrue(br.structure_changed(mapping, deleted, 4, 3))

    def test_insert_and_reorder(self):
        old = [raw_building(x=i, typ=3) for i in (1,2,3)]
        added = raw_building(x=9, typ=6)
        new = [old[2], added, old[0], old[1]]
        mapping, deleted = br.align_buildings(old, new)
        self.assertEqual(mapping, [2, None, 0, 1])
        self.assertEqual(deleted, [])

    def test_event_building_refs_only(self):
        rec = bytearray(range(171))
        rec[30:33] = bytes((1,2,3))
        out = br.remap_event_building_refs(bytes(rec), {2}, {1:2, 3:1})
        self.assertEqual(out[30:33], bytes((2,0,1)))
        for i in range(171):
            if i not in (30,31,32):
                self.assertEqual(out[i], rec[i])


class TestNativeGarrisonSynthesis(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = army_runtime.load_catalog()

    def test_objects2_four_native_garrisons_byte_exact(self):
        cases = [
            (1, [(42,0,1),(19,0,1),(41,0,1),(15,0,1),(13,0,1),(6,0,1)], 20, (), 0,
             '2e67d7a99f2144702c23cffc5e3fbaf2b814f3c68cca882986b87336c6ee8191'),
            (3, [(8,0,1),(19,0,1),(38,0,1)], 15, (), 0,
             'a50bc8860f60623e1ceff225c4277591e8898a067141bc6b0d6378de09fa3bae'),
            (4, [(31,0,1),(34,0,1)], 10, (), 0,
             '3b637c72e7a27f9eae09d0a95e24bb90c119702eb15c72e1fde123c68c9ca8db'),
            (12, [(65,0,1)], 5, (8,33), 100,
             'f61a1f9a0b0ee4c3436a4ffbfea20c150571604da611181d5bc85945c3c0f0c4'),
        ]
        for typ, garrison, defence, artifacts, max_price, expected in cases:
            rec = br.parse_building_record(raw_building(
                typ=typ, defence=defence, garrison=garrison,
                artifacts=artifacts, max_price=max_price,
            ))
            state = br.synthesize_garrison_state(rec, self.catalog, strict=True)
            self.assertEqual(hashlib.sha256(state).hexdigest(), expected)
            self.assertEqual(br.verify_garrison_state(rec, state, self.catalog), [])

    def test_verifier_catches_strength_corruption(self):
        rec = br.parse_building_record(raw_building(typ=3, defence=15, garrison=[(8,0,1)]))
        state = bytearray(br.synthesize_garrison_state(rec, self.catalog, strict=True))
        state[br.G_AGG_STRENGTH_OFF] ^= 1
        self.assertIn('aggregate strength', br.verify_garrison_state(rec, bytes(state), self.catalog))


class TestMarketsAndRuntimeCore(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = army_runtime.load_catalog()

    def test_fixed_market_ids_are_negative(self):
        rec = br.parse_building_record(raw_building(typ=6, artifacts=(3,16,1,5,1,133)))
        slots, approximate = br.initialize_market_slots(rec, self.catalog)
        self.assertFalse(approximate)
        self.assertEqual(slots[:6], [-3,-16,-1,-5,-1,-133])
        self.assertEqual(slots[6:], [0]*6)

    def test_random_market_stock_is_right_aligned(self):
        rec = br.parse_building_record(raw_building(typ=7, market_count=3, min_price=0, max_price=1000))
        slots, approximate = br.initialize_market_slots(rec, self.catalog)
        self.assertTrue(approximate)
        self.assertEqual(slots[:9], [0]*9)
        self.assertTrue(all(v > 0 for v in slots[9:]))

    def test_fixed_items_win_over_overlapping_random_tail(self):
        rec = br.parse_building_record(raw_building(typ=6, artifacts=(3,16,1,5,1,133), market_count=12, min_price=0, max_price=1000))
        slots, _ = br.initialize_market_slots(rec, self.catalog)
        self.assertEqual(slots[:6], [-3,-16,-1,-5,-1,-133])
        self.assertTrue(all(v > 0 for v in slots[6:]))

    def test_altar_editor_artifacts_are_not_runtime_stock(self):
        rec = br.parse_building_record(raw_building(typ=10, artifacts=(99,115)))
        core, _ = br.synthesize_core(rec, self.catalog)
        self.assertEqual(core[br.ARTIFACTS_OFF:br.ARTIFACTS_OFF+24], b'\0'*24)

    def test_village_initializes_current_income_but_castle_does_not(self):
        village = br.parse_building_record(raw_building(typ=2, gold=10, mana=20))
        castle = br.parse_building_record(raw_building(typ=3, gold=50, mana=20))
        vcore, _ = br.synthesize_core(village, self.catalog)
        ccore, _ = br.synthesize_core(castle, self.catalog)
        self.assertEqual(struct.unpack_from('<H', vcore, br.RUNTIME_CURRENT_GOLD_OFF)[0], 10)
        self.assertEqual(vcore[br.RUNTIME_CURRENT_MANA_OFF], 20)
        self.assertEqual(struct.unpack_from('<H', ccore, br.RUNTIME_CURRENT_GOLD_OFF)[0], 0)
        self.assertEqual(ccore[br.RUNTIME_CURRENT_MANA_OFF], 0)

    def test_template_does_not_leak_other_building_income_progress(self):
        rec = br.parse_building_record(raw_building(typ=2, gold=10, mana=20))
        template = bytearray(358)
        struct.pack_into('<H', template, br.RUNTIME_CURRENT_GOLD_OFF, 777)
        template[br.RUNTIME_CURRENT_MANA_OFF] = 99
        core, _ = br.synthesize_core(rec, self.catalog, bytes(template))
        self.assertEqual(struct.unpack_from('<H', core, br.RUNTIME_CURRENT_GOLD_OFF)[0], 10)
        self.assertEqual(core[br.RUNTIME_CURRENT_MANA_OFF], 20)


class TestThreeWayProgress(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = army_runtime.load_catalog()

    def test_recruit_depletion_is_preserved_for_unrelated_edit(self):
        old = bytearray(raw_building(typ=3))
        old[br.RECRUITS_OFF:br.RECRUITS_OFF+3] = bytes((4,5,5))
        new = bytearray(old)
        new[br.GROUP_OFF] = 2
        source = bytearray(old)
        source[br.RECRUITS_OFF:br.RECRUITS_OFF+3] = bytes((4,2,5))
        merged, _ = br.merge_core(bytes(source), br.parse_building_record(bytes(old)), br.parse_building_record(bytes(new)), self.catalog)
        self.assertEqual(tuple(merged[br.RECRUITS_OFF:br.RECRUITS_OFF+3]), (4,2,5))

    def test_explicit_recruit_type_change_resets_slot(self):
        old = bytearray(raw_building(typ=3))
        old[br.RECRUITS_OFF:br.RECRUITS_OFF+3] = bytes((4,5,5))
        new = bytearray(old)
        new[br.RECRUITS_OFF:br.RECRUITS_OFF+3] = bytes((19,3,3))
        source = bytearray(old)
        source[br.RECRUITS_OFF:br.RECRUITS_OFF+3] = bytes((4,1,5))
        merged, _ = br.merge_core(bytes(source), br.parse_building_record(bytes(old)), br.parse_building_record(bytes(new)), self.catalog)
        self.assertEqual(tuple(merged[br.RECRUITS_OFF:br.RECRUITS_OFF+3]), (19,3,3))


class TestRuntimeBuildingIdRemap(unittest.TestCase):
    def test_hero_and_unchanged_npc_start_buildings_remap(self):
        old = [army_runtime.parse_army_record(army_raw(1, 3)), army_runtime.parse_army_record(army_raw(2, 4))]
        new = [army_runtime.parse_army_record(army_raw(1, 3)), army_runtime.parse_army_record(army_raw(2, 9))]
        tail = bytearray((len(new)+1) * army_runtime.RUNTIME_ARMY_SIZE)
        tail[army_runtime.START_BUILDING_OFF] = 4
        tail[army_runtime.RUNTIME_ARMY_SIZE + army_runtime.START_BUILDING_OFF] = 3
        tail[2*army_runtime.RUNTIME_ARMY_SIZE + army_runtime.START_BUILDING_OFF] = 9
        out = br.remap_runtime_start_buildings(bytes(tail), old, new, [0,1], {2}, {3:2,4:3})
        self.assertEqual(out[army_runtime.START_BUILDING_OFF], 3)
        self.assertEqual(out[army_runtime.RUNTIME_ARMY_SIZE + army_runtime.START_BUILDING_OFF], 2)
        # Explicitly edited NPC start building stays under army-sync semantics.
        self.assertEqual(out[2*army_runtime.RUNTIME_ARMY_SIZE + army_runtime.START_BUILDING_OFF], 9)


if __name__ == '__main__':
    unittest.main()
