import copy
import random
import struct
import unittest
from pathlib import Path

import army_runtime as ar

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ar.load_catalog(ROOT / "army_catalog.json")


def marker_record(tag: str, army_id: int) -> bytes:
    b = bytearray(ar.ARMY_RECORD_SIZE)
    b[4] = army_id & 0xFF
    raw = tag.encode("ascii")[:20]
    b[8:8 + len(raw)] = raw
    return bytes(b)


def army_record(
    army_id: int,
    *,
    x: int,
    y: int = 10,
    main_id: int = 4,
    main_level: int = 0,
    troops=(),
    activity: int = 0,
    items=(0, 0, 0),
    spell: int = 0,
    patrol_exists: int = 0,
    patrol_radius: int = 0,
) -> ar.ArmyRecord:
    b = bytearray(ar.ARMY_RECORD_SIZE)
    struct.pack_into("<HH", b, 0, x, y)
    b[4] = army_id
    b[5] = 1
    b[0x1A] = main_id
    b[0x1B] = main_level
    for i, (uid, lvl, amount) in enumerate(troops[:6]):
        b[0x1C + i * 3:0x1F + i * 3] = bytes((uid, lvl, amount))
    b[0x32:0x35] = bytes(items)
    b[0x3C] = patrol_exists
    b[0x3D] = patrol_radius
    b[0x3E] = activity
    b[0x54] = spell
    return ar.parse_army_record(bytes(b))


def rebuilt_block(rec: ar.ArmyRecord, header_byte=0) -> bytes:
    b = bytearray(ar.RUNTIME_ARMY_SIZE)
    b[0x100] = header_byte
    ar.rebuild_composition(b, None, rec, {}, CATALOG, None, {})
    ar.patch_direct_fields(b, None, rec, False)
    return bytes(b)


class TestFormatProfile(unittest.TestCase):
    def test_profile_geometry(self):
        p = ar.LEGACY_V4_PROFILE
        self.assertEqual(p.map_magic, b"MapLDV V.4\r\n")
        self.assertEqual(p.army_record_size, 89)
        self.assertEqual(p.runtime_army_size, 0x3827)
        self.assertEqual(p.unit_stride, 0x1DB)
        self.assertEqual(p.max_units, 12)

    def test_event_reference_schema_exact(self):
        self.assertEqual(
            tuple(ar.EVENT_ARMY_REF_FIELDS),
            (15, 16, 54, 55, 67, 68, 74, 75, 121, 122, 123, 136, 142, 144, 146, 147),
        )
        self.assertEqual(ar.EVENT_ARMY_REF_OFFSETS, tuple(ar.EVENT_ARMY_REF_FIELDS))

    def test_catalog_size(self):
        self.assertEqual(len(CATALOG["units"]), 102)
        self.assertEqual(len(CATALOG["artifacts"]), 167)
        self.assertEqual(len(CATALOG["spells"]), 35)

    def test_native_overlay_has_level0_profile_for_all_102_units(self):
        profiles=CATALOG.get("_native_profiles",{}).get("profiles",{})
        for uid in range(1,103):
            p=profiles.get(f"{uid}:0",{})
            self.assertTrue({"v1","v2","strength","class"} <= set(p), uid)

    def test_contextual_runtime_codes_are_conflict_free(self):
        db=CATALOG.get("_native_profiles",{})
        self.assertGreaterEqual(len(db.get("army_runtime_codes",{})),102)
        self.assertEqual(db.get("army_runtime_code_conflicts",{}),{})


class TestAlignmentCorpus(unittest.TestCase):
    def check(self, old_tags, new_tags, expected_mapping, expected_deleted):
        old = [marker_record(t, i + 1) for i, t in enumerate(old_tags)]
        new = [marker_record(t, i + 1) for i, t in enumerate(new_tags)]
        mapping, deleted = ar.align_armies(old, new)
        self.assertEqual(mapping, expected_mapping)
        self.assertEqual(deleted, expected_deleted)

    def test_noop(self): self.check("ABC", "ABC", [0, 1, 2], [])
    def test_append_one(self): self.check("ABC", "ABCD", [0, 1, 2, None], [])
    def test_append_three(self): self.check("AB", "ABCDE", [0, 1, None, None, None], [])
    def test_delete_first(self): self.check("ABCD", "BCD", [1, 2, 3], [0])
    def test_delete_middle(self): self.check("ABCD", "ACD", [0, 2, 3], [1])
    def test_delete_last(self): self.check("ABCD", "ABC", [0, 1, 2], [3])
    def test_delete_two(self): self.check("ABCDE", "ACE", [0, 2, 4], [1, 3])
    def test_insert_first(self): self.check("ABC", "XABC", [None, 0, 1, 2], [])
    def test_insert_middle(self): self.check("ABC", "AXBC", [0, None, 1, 2], [])
    def test_same_count_delete_append(self): self.check("ABC", "ACX", [0, 2, None], [1])
    def test_same_count_delete_prepend(self): self.check("ABC", "XAB", [None, 0, 1], [2])
    def test_multiple_structure(self):
        # X occupies the exact old B position and is therefore conservatively
        # treated as an in-place edit; D->Y is the structural delete+append.
        self.check("ABCDE", "AXCEY", [0, 1, 2, 4, None], [3])

    def test_same_position_replacement_is_conservative_modify(self):
        self.check("ABC", "AXC", [0, 1, 2], [])
    def test_reorder_all(self): self.check("ABC", "CAB", [2, 0, 1], [])
    def test_reorder_with_delete(self): self.check("ABCDE", "ACED", [0, 2, 4, 3], [1])

    def test_in_place_edit_between_anchors(self):
        old = [marker_record(t, i + 1) for i, t in enumerate("ABC")]
        new = list(old)
        b = bytearray(new[1]); b[40] ^= 7; b[4] = 2; new[1] = bytes(b)
        mapping, deleted = ar.align_armies(old, new)
        self.assertEqual(mapping, [0, 1, 2])
        self.assertEqual(deleted, [])
        self.assertFalse(ar.army_structure_changed(mapping, deleted, 3, 3))

    def test_structure_change_detects_shift(self):
        self.assertTrue(ar.army_structure_changed([0, 2], [1], 3, 2))
        self.assertTrue(ar.army_structure_changed([2, 0, 1], [], 3, 3))
        self.assertTrue(ar.army_structure_changed([0, 2, None], [1], 3, 3))
        self.assertFalse(ar.army_structure_changed([0, 1, 2], [], 3, 3))


class TestRemapping(unittest.TestCase):
    def test_zero_unchanged(self): self.assertEqual(ar.remap_id(0, {2}, {3: 2}), 0)
    def test_ff_unchanged(self): self.assertEqual(ar.remap_id(0xFF, {2}, {3: 2}), 0xFF)
    def test_deleted_to_zero(self): self.assertEqual(ar.remap_id(2, {2}, {3: 2}), 0)
    def test_deleted_to_ff(self): self.assertEqual(ar.remap_id(2, {2}, {3: 2}, deleted_value=0xFF), 0xFF)
    def test_shifted(self): self.assertEqual(ar.remap_id(3, {2}, {3: 2}), 2)
    def test_unaffected(self): self.assertEqual(ar.remap_id(7, {2}, {3: 2}), 7)

    def test_event_remap_touches_only_schema_offsets(self):
        before = bytearray((i * 37 + 11) & 0xFF for i in range(171))
        for off in ar.EVENT_ARMY_REF_OFFSETS:
            before[off] = 3
        after = ar.remap_event_army_refs(bytes(before), {2}, {3: 2})
        changed = [i for i, (a, b) in enumerate(zip(before, after)) if a != b]
        self.assertEqual(changed, list(ar.EVENT_ARMY_REF_OFFSETS))
        self.assertTrue(all(after[i] == 2 for i in ar.EVENT_ARMY_REF_OFFSETS))

    def test_cell_marker_roundtrip(self):
        for army_id in (1, 2, 44, 254):
            marker, kind = ar.encode_army_cell_marker(army_id)
            self.assertEqual(ar.decode_army_cell_marker(marker, kind), army_id)
        self.assertIsNone(ar.decode_army_cell_marker(0, 0))
        self.assertIsNone(ar.decode_army_cell_marker(0x0302, ar.CELL_ARMY_KIND))


class TestModifierAndEquipRules(unittest.TestCase):
    def test_set_add_percent_order(self):
        self.assertEqual(ar._apply_modifier(100, {"f-Hits": "50", "d-Hits": "10", "p-Hits": "20"}, "Hits"), 72)

    def test_negative_percent_truncates_toward_zero(self):
        self.assertEqual(ar._apply_modifier(11, {"p-Hits": "-25"}, "Hits"), 9)

    def test_percent_point_stats_add_points(self):
        self.assertEqual(ar._apply_modifier(20, {"p-ProtectLife": "25"}, "ProtectLife"), 45)

    def test_item_type_not_equipment(self):
        unit = next(iter(CATALOG["units"].values()))
        item = next(x for x in CATALOG["artifacts"].values() if x.get("Type") == "Item")
        self.assertFalse(ar._artifact_compatible(unit, item))

    def test_mecha_rejects_artifacts(self):
        mecha = {"Nature": "Mecha", "AttackBlow": "20", "AttackShot": "20", "MagicPower": "20", "Magic": "LifeMagic"}
        equip = next(x for x in CATALOG["artifacts"].values() if x.get("Type") in {"Armor", "Shield", "Ring", "Amulet"} and not x.get("Magic"))
        self.assertFalse(ar._artifact_compatible(mecha, equip))

    def test_magic_restriction(self):
        restricted = next(x for x in CATALOG["artifacts"].values() if x.get("Magic"))
        required = restricted["Magic"]
        wrong = next(x for x in CATALOG["units"].values() if (x.get("Magic") or "") not in ("", required))
        self.assertFalse(ar._artifact_compatible(wrong, restricted))

    def test_blow_weapon_requires_hand_attack(self):
        item = next(x for x in CATALOG["artifacts"].values() if x.get("Type") == "BlowWeapon" and not x.get("Magic"))
        unit = {"Nature": "People", "AttackBlow": "0", "AttackShot": "10", "MagicPower": "0", "Magic": ""}
        self.assertFalse(ar._artifact_compatible(unit, item))

    def test_shot_weapon_requires_shot_attack(self):
        item = next(x for x in CATALOG["artifacts"].values() if x.get("Type") == "ShotWeapon" and not x.get("Magic"))
        unit = {"Nature": "People", "AttackBlow": "10", "AttackShot": "0", "MagicPower": "0", "Magic": ""}
        self.assertFalse(ar._artifact_compatible(unit, item))

    def test_staff_requires_magic(self):
        item = next(x for x in CATALOG["artifacts"].values() if x.get("Type") == "Staff" and not x.get("Magic"))
        unit = {"Nature": "People", "AttackBlow": "10", "AttackShot": "0", "MagicPower": "0", "Magic": ""}
        self.assertFalse(ar._artifact_compatible(unit, item))

    def test_distribute_never_duplicates_type_on_one_unit(self):
        ids = [int(k) for k, v in CATALOG["artifacts"].items() if v.get("Type") == "Ring" and not v.get("Magic")][:2]
        self.assertEqual(len(ids), 2)
        comp = [(4, 0, True), (19, 0, False)]
        dist = ar.distribute_items(comp, (ids[0], ids[1], 0), CATALOG)
        for assigned in dist:
            types = [CATALOG["artifacts"][str(i)]["Type"] for i in assigned]
            self.assertEqual(len(types), len(set(types)))

    def test_native_greedy_artifact_distribution_four_armies(self):
        # Native Другой берег4 -> Другой берег3: 12/12 items.  The loader
        # evaluates DTm items left-to-right and gives each next item to the
        # compatible unit with the largest immediate tactical-cost gain.
        cases = [
            (
                [(33,9,True),(4,0,False),(4,0,False),(4,0,False),(40,0,False),(40,0,False),
                 (23,0,False),(23,0,False),(26,0,False),(66,0,False),(66,0,False),(20,0,False)],
                (39,144,81),
                {0:[39,144,81]},
            ),
            (
                [(9,0,True),(4,0,False),(8,0,False),(8,0,False),(5,0,False),(16,0,False),(66,0,False)],
                (3,38,157),
                {5:[3,38,157]},
            ),
            (
                [(14,0,True),(13,0,False),(11,0,False),(12,0,False),(12,0,False),(15,0,False),(10,0,False)],
                (34,44,56),
                {1:[34,44,56]},
            ),
            (
                [(19,0,True),(20,0,False),(20,0,False),(86,0,False),(87,0,False),(21,0,False),(95,0,False),(80,0,False)],
                (33,29,65),
                {5:[33],7:[29,65]},
            ),
        ]
        for comp, items, expected in cases:
            dist = ar.distribute_items(comp, items, CATALOG)
            self.assertEqual({i:v for i,v in enumerate(dist) if v}, expected)

    def test_only_one_weapon_slot_per_unit(self):
        comp = [(21,0,True),(80,0,False)]
        dist = ar.distribute_items(comp, (33,29,0), CATALOG)
        self.assertEqual(sum(len(x) for x in dist), 2)
        for assigned in dist:
            weapon_count=sum(
                1 for iid in assigned
                if CATALOG['artifacts'][str(iid)].get('Type') in ar._ARTIFACT_WEAPON_TYPES
            )
            self.assertLessEqual(weapon_count,1)


class TestUnitRecordAndVerifier(unittest.TestCase):
    def test_make_militia_offsets(self):
        u = ar.make_unit_record(4, 0, True, 0, 0, [], CATALOG)
        self.assertEqual(len(u), ar.UNIT_STRIDE)
        self.assertEqual(struct.unpack_from("<I", u, 0)[0], 3)
        self.assertEqual(struct.unpack_from("<I", u, 0x10)[0], 0)
        self.assertEqual(struct.unpack_from("<I", u, 0x1AA)[0], 63)
        self.assertEqual(struct.unpack_from("<I", u, 0x1B2)[0], 4)

    def test_make_hunter_class(self):
        u = ar.make_unit_record(19, 0, False, 0, 0, [], CATALOG)
        self.assertEqual(struct.unpack_from("<I", u, 0x1B2)[0], 7)
        self.assertEqual(u[0x19D], 1)

    def test_make_bombardier_strength(self):
        u = ar.make_unit_record(24, 0, False, 0, 0, [], CATALOG)
        self.assertEqual(struct.unpack_from("<I", u, 0x1AA)[0], 562)
        self.assertEqual(struct.unpack_from("<I", u, 0x1AE)[0], 562)

    def test_known_artifact_spell_derived_fields(self):
        u = ar.make_unit_record(4, 0, False, 0, 18, [14], CATALOG, strict_derived=True)
        # Artifact 14 fixes initiative to 15; spell 18 drives melee defence
        # below zero in the live modified copy and C-copy clamps it to zero.
        self.assertEqual(struct.unpack_from("<i", u, 0x0DD + ar.STAT_FIELDS["Initiative"])[0], 15)
        self.assertEqual(struct.unpack_from("<i", u, 0x0DD + ar.STAT_FIELDS["DefenceBlow"])[0], -4)
        self.assertEqual(struct.unpack_from("<i", u, 0x15D + ar.STAT_FIELDS["DefenceBlow"])[0], 0)
        self.assertEqual(struct.unpack_from("<I", u, 0x1AE)[0], 102)

    def test_all_102_profiles_synthesize_in_research_mode(self):
        for uid in sorted(map(int, CATALOG["units"])):
            with self.subTest(uid=uid):
                u = ar.make_unit_record(uid, 0, False, 0, 0, [], CATALOG, strict_derived=False)
                self.assertEqual(len(u), ar.UNIT_STRIDE)
                self.assertEqual(struct.unpack_from("<I", u, 0)[0] + 1, uid)

    def test_strict_mode_refuses_uncertified_profile(self):
        # The New/New1 corpus certifies all 102 Unit IDs, so use a deliberately
        # unobserved level to verify byte-exact strict behavior still refuses
        # extrapolation from the editor formula alone.
        with self.assertRaisesRegex(ValueError, "нативно подтвержд"):
            ar.make_unit_record(4, 99, False, 0, 0, [], CATALOG, strict_derived=True)

    def test_upkeep_formula_is_level_independent(self):
        expected = {4: 6, 19: 22, 24: 130, 65: 18}
        for uid, payment in expected.items():
            with self.subTest(uid=uid):
                self.assertEqual(ar._payment_guess(uid, 0, CATALOG), payment)
                self.assertEqual(ar._payment_guess(uid, 9, CATALOG), payment)

    def test_tactical_formula_known_native_profiles(self):
        # Ordinary units and the two runtime-swapped God* bonuses are exact.
        for uid, level in ((4, 0), (19, 0), (24, 0), (35, 6), (36, 6)):
            with self.subTest(uid=uid, level=level):
                unit = CATALOG["units"][str(uid)]
                stats = ar._base_stats(unit, level)
                got = ar.calculate_tactical_components(stats, unit, unit.get("Bonus") or "", runtime_compat=True)
                prof = ar._profile_for(uid, level, CATALOG)
                self.assertEqual((got["v1"], got["v2"], got["tactical_cost"]),
                                 (prof["v1"], prof["v2"], prof["strength"]))

    def test_modified_native_overlay_supplies_v1_v2_strength(self):
        db = CATALOG.get("_native_profiles", {}).get("modified_profiles", {})
        self.assertGreaterEqual(len(db), 80)
        key, value = next(iter(db.items()))
        uid, level, item_text, spell = key.split(":")
        items = [int(x) for x in item_text.split(",") if int(x)]
        p = ar._native_modified_profile(int(uid), int(level), items, int(spell), CATALOG)
        self.assertEqual(p["v1"], int(value["v1"]))
        self.assertEqual(p["v2"], int(value["v2"]))
        self.assertEqual(p["strength"], int(value["strength"]))

    def test_count_12_allowed(self):
        rec = army_record(1, x=1, main_id=4, troops=((19, 0, 11),))
        b = rebuilt_block(rec)
        self.assertEqual(struct.unpack_from("<I", b, ar.UNIT_COUNT_OFF)[0], 12)
        self.assertTrue(ar.verify_runtime_army_block(b, CATALOG, expected_comp=rec.expanded(), rebuilt=True)["ok"])

    def test_count_13_refused(self):
        rec = army_record(1, x=1, main_id=4, troops=((19, 0, 12),))
        with self.assertRaisesRegex(ValueError, "12"):
            rebuilt_block(rec)

    def test_native_count_corruption_refused(self):
        b = bytearray(ar.RUNTIME_ARMY_SIZE)
        struct.pack_into("<I", b, ar.UNIT_COUNT_OFF, 13)
        with self.assertRaisesRegex(ValueError, "13"):
            ar.native_comp_from_block(bytes(b))

    def test_verifier_detects_aggregate_strength(self):
        rec = army_record(1, x=1, main_id=4)
        b = bytearray(rebuilt_block(rec))
        struct.pack_into("<I", b, ar.AGG_STRENGTH_OFF, 999)
        report = ar.verify_runtime_army_block(bytes(b), CATALOG, expected_comp=rec.expanded(), rebuilt=True)
        self.assertFalse(report["ok"])
        self.assertTrue(any("aggregate_strength" in x for x in report["issues"]))

    def test_verifier_detects_hp_sum(self):
        rec = army_record(1, x=1, main_id=4)
        b = bytearray(rebuilt_block(rec))
        struct.pack_into("<I", b, ar.HP_SUM_OFF, 999)
        report = ar.verify_runtime_army_block(bytes(b), CATALOG, expected_comp=rec.expanded(), rebuilt=True)
        self.assertFalse(report["ok"])
        self.assertTrue(any("hp_sum" in x for x in report["issues"]))

    def test_verifier_detects_formation(self):
        rec = army_record(1, x=1, main_id=4)
        b = bytearray(rebuilt_block(rec))
        struct.pack_into("<i", b, ar.FORMATION_OFF, 99)
        report = ar.verify_runtime_army_block(bytes(b), CATALOG, expected_comp=rec.expanded(), rebuilt=True)
        self.assertFalse(report["ok"])
        self.assertTrue(any("formation" in x for x in report["issues"]))

    def test_profile_coverage_accounts_for_all_catalog_units(self):
        r = ar.exact_profile_coverage(CATALOG)
        self.assertEqual(r["catalog_units"], 102)
        self.assertEqual(r["exact_count"] + r["heuristic_count"], 102)


class TestNativeFormation(unittest.TestCase):
    @staticmethod
    def unit_record(strength, *, blow=0, shot=0, magic=0):
        b=bytearray(ar.UNIT_STRIDE)
        struct.pack_into("<I", b, 0x1AE, strength)
        base=0xDD
        struct.pack_into("<i", b, base+ar.STAT_FIELDS["AttackBlow"], blow)
        struct.pack_into("<i", b, base+ar.STAT_FIELDS["AttackShot"], shot)
        struct.pack_into("<i", b, base+ar.STAT_FIELDS["MagicPower"], magic)
        return bytes(b)

    def test_native_12_unit_append_formation_exact(self):
        # Native army #62 from the supplied base -> 12-unit append control.
        records=[
            self.unit_record(2075, magic=89),
            self.unit_record(63, blow=25),
            self.unit_record(63, blow=25),
            self.unit_record(63, blow=25),
            self.unit_record(343, blow=40),
            self.unit_record(343, blow=40),
            self.unit_record(258, shot=40),
            self.unit_record(258, shot=40),
            self.unit_record(84, magic=15),
            self.unit_record(135, blow=35),
            self.unit_record(135, blow=35),
            self.unit_record(578, magic=25),
        ]
        self.assertEqual(
            ar._formation(records),
            [3,11,6,5,10,2,-1,8,12,1,7,-1,-1,-1,4,9,-1,-1],
        )

    def test_seventh_front_unit_spills_instead_of_disappearing(self):
        records=[self.unit_record(100-i, blow=20) for i in range(7)]
        form=ar._formation(records)
        placed=[x for i,x in enumerate(form) if i not in ar.FORMATION_SENTINELS and x]
        self.assertEqual(sorted(placed), list(range(1,8)))
        self.assertEqual(len(placed), 7)

    def test_single_magic_unit_is_front_center(self):
        form=ar._formation([self.unit_record(500, magic=50)])
        self.assertEqual(form[3], 1)
        self.assertEqual(sum(x>0 for x in form), 1)


class TestNativeArmyDirectFields(unittest.TestCase):
    def test_exact_runtime_code_requires_context_profile(self):
        rec=army_record(1,x=10,main_id=33,main_level=9)
        key=ar._army_runtime_context_key(rec)
        catalog={"_native_profiles":{"army_runtime_codes":{key:10},"leader_runtime_codes":{"33":99}}}
        self.assertEqual(ar._leader_runtime_code(rec,catalog),10)
        b=bytearray(ar.RUNTIME_ARMY_SIZE)
        ar.patch_direct_fields(b,None,rec,False,catalog)
        self.assertEqual(struct.unpack_from("<I",b,ar.LEADER_RUNTIME_CODE_OFF)[0],10)

    def test_per_unit_runtime_code_is_not_used_without_context(self):
        rec=army_record(1,x=10,main_id=33,main_level=9)
        catalog={"_native_profiles":{"leader_runtime_codes":{"33":10}}}
        self.assertIsNone(ar._leader_runtime_code(rec,catalog))

    def test_runtime_context_key_ignores_coordinates_and_army_id(self):
        a=army_record(1,x=10,main_id=33,main_level=9)
        b=army_record(9,x=99,main_id=33,main_level=9)
        self.assertEqual(ar._army_runtime_context_key(a),ar._army_runtime_context_key(b))

    def test_named_leader_does_not_assume_unit_code(self):
        b=bytearray(89); struct.pack_into("<HH",b,0,10,10); b[4]=1; b[0x1A]=33; b[0x3A]=1
        rec=ar.parse_army_record(bytes(b))
        self.assertIsNone(ar._leader_runtime_code(rec,CATALOG))

    def test_patrol_mode_native_rule(self):
        normal=army_record(1,x=10,patrol_exists=0,patrol_radius=0)
        zero_radius=army_record(1,x=10,patrol_exists=1,patrol_radius=0)
        radius=army_record(1,x=10,patrol_exists=1,patrol_radius=7)
        for rec,expected in ((normal,5),(zero_radius,8),(radius,5)):
            b=bytearray(ar.RUNTIME_ARMY_SIZE)
            ar.patch_direct_fields(b,None,rec,False)
            self.assertEqual(struct.unpack_from("<I",b,ar.PATROL_MODE_OFF)[0],expected)


class TestTailStructuralEdits(unittest.TestCase):
    def make_source(self):
        recs = [
            army_record(1, x=11, main_id=4),
            army_record(2, x=22, main_id=19),
            army_record(3, x=33, main_id=24),
        ]
        blocks = [rebuilt_block(r, 0xA0 + i) for i, r in enumerate(recs)]
        hero = bytes(ar.RUNTIME_ARMY_SIZE)
        residual = bytearray(ar.RUNTIME_ARMY_SIZE)
        residual[0x100] = 0xD0
        struct.pack_into("<I", residual, ar.SLOT_POINTER_OFF, 0x800000)
        return recs, blocks, hero + b"".join(blocks) + bytes(residual)

    def test_insert_middle_uses_destination_slot_header(self):
        old, blocks, tail = self.make_source()
        new = [old[0], army_record(2, x=18, main_id=4), copy.copy(old[1]), copy.copy(old[2])]
        # IDs are structural; make raw ID bytes match target positions.
        new_raw=[]
        for i,r in enumerate(new,1):
            b=bytearray(r.raw); b[4]=i; new_raw.append(ar.parse_army_record(bytes(b)))
        mapping, deleted = ar.align_armies([r.raw for r in old], [r.raw for r in new_raw])
        self.assertEqual(mapping, [0, None, 1, 2])
        out = ar.sync_army_tail(tail, old, new_raw, mapping, CATALOG)
        # target slot #2 (index1) keeps old destination slot #2 header
        slot2 = out[2 * ar.RUNTIME_ARMY_SIZE:3 * ar.RUNTIME_ARMY_SIZE]
        self.assertEqual(slot2[0x100], 0xA1)
        # shifted old army #2 now in destination slot #3 => header from old slot #3
        slot3 = out[3 * ar.RUNTIME_ARMY_SIZE:4 * ar.RUNTIME_ARMY_SIZE]
        self.assertEqual(slot3[0x100], 0xA2)
        # shifted old army #3 appended => header from residual next slot
        slot4 = out[4 * ar.RUNTIME_ARMY_SIZE:5 * ar.RUNTIME_ARMY_SIZE]
        self.assertEqual(slot4[0x100], 0xD0)

    def test_same_count_delete_add_sync(self):
        old, blocks, tail = self.make_source()
        new = [old[0], old[2], army_record(3, x=44, main_id=4)]
        fixed=[]
        for i,r in enumerate(new,1):
            b=bytearray(r.raw); b[4]=i; fixed.append(ar.parse_army_record(bytes(b)))
        mapping, deleted = ar.align_armies([r.raw for r in old], [r.raw for r in fixed])
        self.assertEqual(mapping, [0, 2, None])
        self.assertEqual(deleted, [1])
        out = ar.sync_army_tail(tail, old, fixed, mapping, CATALOG)
        report = ar.verify_synced_tail(out, fixed, CATALOG, rebuilt_indices={2})
        self.assertTrue(report["ok"], report["issues"])

    def test_reorder_preserves_destination_headers(self):
        old, blocks, tail = self.make_source()
        new = [old[2], old[0], old[1]]
        fixed=[]
        for i,r in enumerate(new,1):
            b=bytearray(r.raw); b[4]=i; fixed.append(ar.parse_army_record(bytes(b)))
        mapping, deleted = ar.align_armies([r.raw for r in old], [r.raw for r in fixed])
        self.assertEqual(mapping, [2, 0, 1])
        self.assertEqual(deleted, [])
        out=ar.sync_army_tail(tail, old, fixed, mapping, CATALOG)
        headers=[]
        for i in range(3):
            block=out[(i+1)*ar.RUNTIME_ARMY_SIZE:(i+2)*ar.RUNTIME_ARMY_SIZE]
            headers.append(block[0x100])
        self.assertEqual(headers, [0xA0, 0xA1, 0xA2])


class TestNativeArtifactRuntimeDetails(unittest.TestCase):
    @staticmethod
    def _fake_unit(*, front: bool, strength: int) -> bytes:
        b = bytearray(ar.UNIT_STRIDE)
        base = 0xDD
        # _formation_prefers_front reads the modified DD-copy attack channels.
        struct.pack_into('<i', b, base + ar.STAT_FIELDS['AttackBlow'], 20 if front else 0)
        struct.pack_into('<i', b, base + ar.STAT_FIELDS['AttackShot'], 0 if front else 20)
        struct.pack_into('<i', b, base + ar.STAT_FIELDS['MagicPower'], 0)
        struct.pack_into('<I', b, 0x1AE, strength)
        return bytes(b)

    def test_existing_artifact_resort_preserves_overflow(self):
        # Existing formations are not rebuilt from scratch when only item/spell
        # semantics change. Native Другой берег4 -> Другой берег3 keeps an
        # overflow front-preferring troop in the back lane and re-sorts only
        # troops already occupying their natural lane.
        records = [
            self._fake_unit(front=True, strength=10),
            self._fake_unit(front=True, strength=90),
            self._fake_unit(front=True, strength=70),
            self._fake_unit(front=False, strength=60),
        ]
        block = bytearray(ar.RUNTIME_ARMY_SIZE)
        vals = [0] * 18
        for ix in ar.FORMATION_SENTINELS:
            vals[ix] = -1
        logical = [0] * 12
        # Front natural slots contain units 1 and 2; unit 3 is an overflow
        # melee troop already parked in a back slot. Unit 4 is naturally back.
        logical[3] = 1
        logical[2] = 2
        logical[8] = 3
        logical[7] = 4
        for j, e in enumerate(ar.FORMATION_ENTRIES):
            vals[e] = logical[j]
        for i, v in enumerate(vals):
            struct.pack_into('<i', block, ar.FORMATION_OFF + i * 4, v)

        out = ar._resort_existing_formation(bytes(block), records)
        got = [out[e] for e in ar.FORMATION_ENTRIES]
        # Unit 2 (stronger) takes the first front slot. Unit 3 must stay in its
        # overflow back slot; it is not pulled into the primary front lane.
        self.assertEqual(got[3], 2)
        self.assertEqual(got[2], 1)
        self.assertEqual(got[8], 3)
        self.assertEqual(got[7], 4)

    def test_existing_template_preserves_model_code(self):
        # +0x18 varies between otherwise equivalent native loads. If the same
        # unit keeps the same main/non-main role, semantic item rebuilds must
        # preserve this opaque runtime byte instead of re-synthesizing it.
        template = bytearray(ar.UNIT_STRIDE)
        struct.pack_into('<I', template, 0, 3)  # UID 4 -> ID0 3
        struct.pack_into('<I', template, 0x10, 0)
        struct.pack_into('<I', template, 0x18, 0xA5)
        template[0x19D] = 0  # main unit
        # Use research mode here: the assertion concerns preservation of the
        # opaque model field, not exact derived-profile availability.
        out = ar.make_unit_record(4, 0, True, 0, 0, [], CATALOG, bytes(template), strict_derived=False)
        self.assertEqual(struct.unpack_from('<I', out, 0x18)[0], 0xA5)



class TestPropertyCorpus(unittest.TestCase):
    def test_50_delete_insert_roundtrips(self):
        # Formal generated corpus: 50 same-count structural edits.  Every case
        # retains at least two exact anchors and must identify one deletion and
        # one addition without mistaking it for an in-place record edit.
        base_tags = [f"A{i:02d}" for i in range(8)]
        for case in range(50):
            with self.subTest(case=case):
                old = [marker_record(t, i + 1) for i, t in enumerate(base_tags)]
                delete = 1 + (case % 6)
                insert = 1 + ((case * 3 + 2) % 6)
                if insert == delete:
                    insert = 1 + (insert % 6)
                tags = base_tags[:]
                tags.pop(delete)
                tags.insert(insert, f"X{case:02d}")
                new = [marker_record(t, i + 1) for i, t in enumerate(tags)]
                mapping, deleted = ar.align_armies(old, new)
                self.assertEqual(deleted, [delete])
                self.assertEqual(sum(x is None for x in mapping), 1)
                mapped = [x for x in mapping if x is not None]
                self.assertEqual(sorted(mapped), sorted(set(range(8)) - {delete}))
                self.assertTrue(ar.army_structure_changed(mapping, deleted, 8, 8))

    def test_multiple_add_delete_keeps_all_exact_survivors(self):
        old_tags = [f"U{i}" for i in range(13)]
        new_tags = ["U0", "U1", "N1", "U3", "U4", "N0", "U5", "U7", "U8", "U9", "U10", "U11", "U12"]
        old = [marker_record(t, i + 1) for i, t in enumerate(old_tags)]
        new = [marker_record(t, i + 1) for i, t in enumerate(new_tags)]
        mapping, deleted = ar.align_armies(old, new)
        # Without a stable GUID/operation log U2->N1 in the same structural
        # lane is observationally indistinguishable from an in-place edit.
        # The conservative policy therefore preserves U2 runtime state while
        # still locking every exact survivor and identifying U6 as deleted.
        self.assertEqual(mapping, [0, 1, 2, 3, 4, None, 5, 7, 8, 9, 10, 11, 12])
        self.assertEqual(deleted, [6])

    def test_exact_survivors_never_consumed_fuzz_2000(self):
        rng = random.Random(0x4558414354)
        for case in range(2000):
            n = rng.randint(1, 24)
            old_tags = [f"E{case:04d}_{i:02d}" for i in range(n)]
            tags = old_tags[:]
            for op in range(rng.randint(0, 5)):
                roll = rng.random()
                if tags and roll < 0.42:
                    tags.pop(rng.randrange(len(tags)))
                elif roll < 0.84:
                    tags.insert(rng.randrange(len(tags) + 1), f"N{case:04d}_{op}")
                elif len(tags) >= 2:
                    a, b = rng.sample(range(len(tags)), 2)
                    tags[a], tags[b] = tags[b], tags[a]
            old = [marker_record(t, i + 1) for i, t in enumerate(old_tags)]
            new = [marker_record(t, i + 1) for i, t in enumerate(tags)]
            mapping, deleted = ar.align_armies(old, new)
            for target, tag in enumerate(tags):
                if tag in old_tags:
                    self.assertEqual(mapping[target], old_tags.index(tag), (case, target, tag, mapping))
            mapped = {x for x in mapping if x is not None}
            self.assertFalse(mapped & set(deleted))
            self.assertEqual(sorted(mapped | set(deleted)), list(range(n)))

    def test_seeded_alignment_fuzz_500(self):
        rng = random.Random(0x5153594E43)
        for case in range(500):
            n = rng.randint(1, 20)
            old_tags = [f"U{case:03d}_{i:02d}" for i in range(n)]
            old = [marker_record(t, i + 1) for i, t in enumerate(old_tags)]
            tags = old_tags[:]
            # Up to three ordered structural operations; replacements at the
            # exact same slot are intentionally allowed to be conservative edits.
            for op in range(rng.randint(0, 3)):
                if tags and rng.random() < 0.5:
                    tags.pop(rng.randrange(len(tags)))
                else:
                    tags.insert(rng.randrange(len(tags) + 1), f"N{case:03d}_{op}")
            new = [marker_record(t, i + 1) for i, t in enumerate(tags)]
            mapping, deleted = ar.align_armies(old, new)
            self.assertEqual(len(mapping), len(new))
            mapped = [x for x in mapping if x is not None]
            self.assertEqual(len(mapped), len(set(mapped)))
            self.assertTrue(all(0 <= x < len(old) for x in mapped))
            self.assertTrue(all(0 <= x < len(old) for x in deleted))
            self.assertFalse(set(mapped) & set(deleted))


if __name__ == "__main__":
    unittest.main(verbosity=2)
